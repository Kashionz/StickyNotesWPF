﻿using System;
using System.ComponentModel;
using System.Windows.Media;

namespace StickyNotesWPF
{
    public class NoteModel : INotifyPropertyChanged
    {
        public Guid Id { get; set; } = Guid.NewGuid();
        public DateTime CreationTime { get; set; } = DateTime.Now;

        // 確保 Content 不為 null
        private string _content = "";
        public string Content
        {
            get { return _content; }
            set
            {
                if (_content != value)
                {
                    _content = value ?? ""; // 確保不為null
                    OnPropertyChanged(nameof(Content));
                }
            }
        }

        // 格式化的創建時間
        public string FormattedCreationTime
        {
            get
            {
                return CreationTime.ToString("yyyy-MM-dd HH:mm");
            }
        }

        // 確保 BackgroundColor 不為 null
        private SolidColorBrush _backgroundColor = new SolidColorBrush(Color.FromRgb(246, 185, 59));
        public SolidColorBrush BackgroundColor
        {
            get { return _backgroundColor; }
            set
            {
                if (_backgroundColor != value)
                {
                    _backgroundColor = value ?? new SolidColorBrush(Color.FromRgb(246, 185, 59));
                    OnPropertyChanged(nameof(BackgroundColor));
                }
            }
        }

        // 確保 FontFamily 不為 null
        private FontFamily _fontFamily = new FontFamily(".蘋方-繁");
        public FontFamily FontFamily
        {
            get { return _fontFamily; }
            set
            {
                if (_fontFamily != value)
                {
                    _fontFamily = value ?? new FontFamily(".蘋方-繁");
                    OnPropertyChanged(nameof(FontFamily));
                }
            }
        }

        // 字體大小
        private double _fontSize = 16;
        public double FontSize
        {
            get { return _fontSize; }
            set
            {
                if (_fontSize != value)
                {
                    _fontSize = value;
                    OnPropertyChanged(nameof(FontSize));
                }
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}