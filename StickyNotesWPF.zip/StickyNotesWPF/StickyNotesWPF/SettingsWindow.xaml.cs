using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace StickyNotesWPF
{
    public partial class SettingsWindow : Window
    {
        public SettingsWindow()
        {
            InitializeComponent();
            LoadSettings();
        }

        private void LoadSettings()
        {
            // 從應用程式設定中載入當前設定值
            // 這裡之後可以連接到應用程式的設定系統
        }

        private void SaveSettings()
        {
            // 保存設定到應用程式配置
            // 處理主題選擇
            string selectedTheme = (ThemeComboBox.SelectedItem as ComboBoxItem)?.Content.ToString();
            
            // 處理預設顏色
            string defaultColor = (DefaultColorComboBox.SelectedItem as ComboBoxItem)?.Content.ToString();
            
            // 處理預設字體大小
            string defaultFontSize = (DefaultFontSizeComboBox.SelectedItem as ComboBoxItem)?.Content.ToString();
            
            // 處理其他選項
            bool autoStart = AutoStartCheckBox.IsChecked ?? false;
            bool autoSave = AutoSaveCheckBox.IsChecked ?? true;
            
            // 顯示保存成功的訊息
            //MessageBox.Show("設定已保存", "提示", MessageBoxButton.OK, MessageBoxImage.Information);
            
            //this.Close();
        }

        private void TitleBar_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            this.DragMove();
        }

        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            SaveSettings();
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}