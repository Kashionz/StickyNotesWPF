﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Effects;

namespace StickyNotesWPF
{
    public partial class NotePreviewControl : UserControl
    {
        public event EventHandler<Guid> OpenNoteRequested;
        public event EventHandler<Guid> DeleteNoteRequested;

        public NoteModel NoteData { get; private set; }

        public NotePreviewControl(NoteModel noteModel)
        {
            InitializeComponent();
            NoteData = noteModel;
            DataContext = NoteData;

            // 注冊滑鼠事件
            NoteBorder.MouseEnter += NoteBorder_MouseEnter;
            NoteBorder.MouseLeave += NoteBorder_MouseLeave;
        }

        private void NoteBorder_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            // 點擊便利貼區域時觸發開啟事件
            OpenNoteRequested?.Invoke(this, NoteData.Id);
        }

        private void DeleteButton_Click(object sender, RoutedEventArgs e)
        {
            // 刪除按鈕事件處理
            e.Handled = true; // 防止事件冒泡到點擊便利貼事件
            DeleteNoteRequested?.Invoke(this, NoteData.Id);
        }

        // 滑鼠進入事件處理
        private void NoteBorder_MouseEnter(object sender, MouseEventArgs e)
        {
            // 邊框粗細變化（維持在邊界內）
            var borderAnimation = new ThicknessAnimation(
                new Thickness(1.5),
                TimeSpan.FromSeconds(0.15));
            NoteBorder.BeginAnimation(Border.BorderThicknessProperty, borderAnimation);

            // 陰影效果增強 - 重要：只在外層ShadowBorder上應用陰影
            var blurAnimation = new DoubleAnimation(10, TimeSpan.FromSeconds(0.15));
            var opacityAnimation = new DoubleAnimation(0.25, TimeSpan.FromSeconds(0.15));
            var depthAnimation = new DoubleAnimation(3, TimeSpan.FromSeconds(0.15));

            ShadowEffect.BeginAnimation(DropShadowEffect.BlurRadiusProperty, blurAnimation);
            ShadowEffect.BeginAnimation(DropShadowEffect.OpacityProperty, opacityAnimation);
            ShadowEffect.BeginAnimation(DropShadowEffect.ShadowDepthProperty, depthAnimation);

            // 邊框顏色變化
            NoteBorder.BorderBrush = new SolidColorBrush(Color.FromRgb(100, 100, 100));
        }

        // 滑鼠離開事件處理
        private void NoteBorder_MouseLeave(object sender, MouseEventArgs e)
        {
            // 還原邊框粗細
            var borderAnimation = new ThicknessAnimation(
                new Thickness(1),
                TimeSpan.FromSeconds(0.15));
            NoteBorder.BeginAnimation(Border.BorderThicknessProperty, borderAnimation);

            // 還原陰影效果
            var blurAnimation = new DoubleAnimation(8, TimeSpan.FromSeconds(0.15));
            var opacityAnimation = new DoubleAnimation(0.2, TimeSpan.FromSeconds(0.15));
            var depthAnimation = new DoubleAnimation(2, TimeSpan.FromSeconds(0.15));

            ShadowEffect.BeginAnimation(DropShadowEffect.BlurRadiusProperty, blurAnimation);
            ShadowEffect.BeginAnimation(DropShadowEffect.OpacityProperty, opacityAnimation);
            ShadowEffect.BeginAnimation(DropShadowEffect.ShadowDepthProperty, depthAnimation);

            // 還原邊框顏色
            NoteBorder.BorderBrush = new SolidColorBrush(Color.FromRgb(225, 225, 225)); // #e1e1e1
        }
    }
}