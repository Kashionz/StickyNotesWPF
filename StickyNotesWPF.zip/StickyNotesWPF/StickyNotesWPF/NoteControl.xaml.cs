﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace StickyNotesWPF
{
    public partial class NoteControl : UserControl
    {
        public event EventHandler DeleteRequested;

        public NoteControl()
        {
            InitializeComponent();
        }

        private void DeleteButton_Click(object sender, RoutedEventArgs e)
        {
            DeleteRequested?.Invoke(this, EventArgs.Empty);
        }

        private void ColorButton_Click(object sender, RoutedEventArgs e)
        {
            // 輪換便利貼顏色
            if (DataContext is NoteModel note)
            {
                if (note.BackgroundColor.Color == Colors.Yellow)
                    note.BackgroundColor = new SolidColorBrush(Colors.LightGreen);
                else if (note.BackgroundColor.Color == Colors.LightGreen)
                    note.BackgroundColor = new SolidColorBrush(Colors.LightBlue);
                else if (note.BackgroundColor.Color == Colors.LightBlue)
                    note.BackgroundColor = new SolidColorBrush(Colors.LightPink);
                else
                    note.BackgroundColor = new SolidColorBrush(Colors.Yellow);
            }
        }
    }
}