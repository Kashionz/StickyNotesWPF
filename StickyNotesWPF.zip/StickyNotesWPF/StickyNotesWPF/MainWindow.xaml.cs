﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using Newtonsoft.Json;
using System.Linq;
using System.Windows.Input;
using StickyNotesWPF.Properties;

namespace StickyNotesWPF
{
    public partial class MainWindow : Window
    {
        private List<NoteModel> _notes;
        private Dictionary<Guid, NoteWindow> _openNoteWindows;
        private string SaveFilePath = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
            "StickyNotesWPF", "notes.json");

        public MainWindow()
        {
            InitializeComponent();

            // 確保保存目錄存在
            string saveDir = Path.GetDirectoryName(SaveFilePath);
            if (!Directory.Exists(saveDir))
            {
                Directory.CreateDirectory(saveDir);
            }

            _notes = new List<NoteModel>();
            _openNoteWindows = new Dictionary<Guid, NoteWindow>();

            // 加載已有便利貼
            LoadNotes();

            // 更新便利貼列表
            UpdateNotesList();

            // 視窗關閉時自動保存
            this.Closing += (s, e) => SaveAll();
        }

        private void CreateNewNote(NoteModel noteModel = null)
        {
            // Pass the CreateNewNote method as a callback to the NoteWindow
            NoteWindow noteWindow = new NoteWindow(noteModel, () => CreateNewNote());
            noteWindow.Show();
        }

        // 自動保存所有便利貼
        private void SaveAll()
        {
            try
            {
                List<NoteSerialized> serializedNotes = new List<NoteSerialized>();

                foreach (var note in _notes)
                {
                    // 檢查是否已經是 NoteSerialized 類型
                    NoteSerialized serializedNote;
                    if (note is NoteSerialized)
                    {
                        serializedNote = (NoteSerialized)note;
                        // 更新顏色和字體名稱
                        serializedNote.BackgroundColorName = GetColorName(note.BackgroundColor.Color);
                        serializedNote.FontFamilyName = note.FontFamily.Source;
                    }
                    else
                    {
                        serializedNote = new NoteSerialized
                        {
                            Id = note.Id,
                            Content = note.Content,
                            CreationTime = note.CreationTime,
                            BackgroundColor = note.BackgroundColor,
                            BackgroundColorName = GetColorName(note.BackgroundColor.Color),
                            FontFamily = note.FontFamily,
                            FontFamilyName = note.FontFamily.Source,
                            FontSize = note.FontSize
                        };
                    }

                    // 如果窗口打開，保存窗口位置
                    if (_openNoteWindows.TryGetValue(note.Id, out NoteWindow window))
                    {
                        serializedNote.WindowLeft = window.Left;
                        serializedNote.WindowTop = window.Top;
                        serializedNote.WindowWidth = window.Width;
                        serializedNote.WindowHeight = window.Height;
                    }

                    serializedNotes.Add(serializedNote);
                }

                string jsonString = JsonConvert.SerializeObject(serializedNotes, Formatting.Indented);
                File.WriteAllText(SaveFilePath, jsonString);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"保存失敗: {ex.Message}", "錯誤", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        // 新增便利貼
        public void AddNote_Click(object sender, RoutedEventArgs e)
        {
            var note = new NoteModel(); // 創建一個新的便利貼
            _notes.Add(note);

            UpdateNotesList();
            OpenNote(note.Id);

            // 自動保存
            SaveAll();
        }

        // 打開便利貼
        private void OpenNote(Guid noteId)
        {
            // 如果該便利貼已經打開，就把窗口前置
            if (_openNoteWindows.ContainsKey(noteId))
            {
                _openNoteWindows[noteId].Activate();
                return;
            }

            // 查找對應的便利貼
            var note = _notes.FirstOrDefault(n => n.Id == noteId);
            if (note != null)
            {
                // 創建並打開新窗口
                var noteWindow = new NoteWindow(note);

                // 如果是序列化的便利貼並且有位置信息，則應用位置信息
                if (note is NoteSerialized serializedNote)
                {
                    if (serializedNote.WindowLeft != 0 && serializedNote.WindowTop != 0)
                    {
                        noteWindow.Left = serializedNote.WindowLeft;
                        noteWindow.Top = serializedNote.WindowTop;
                    }
                    if (serializedNote.WindowWidth > 0 && serializedNote.WindowHeight > 0)
                    {
                        noteWindow.Width = serializedNote.WindowWidth;
                        noteWindow.Height = serializedNote.WindowHeight;
                    }
                }

                // 註冊關閉事件
                noteWindow.Closed += (s, e) =>
                {
                    _openNoteWindows.Remove(noteId);
                    SaveAll(); // 關閉時自動保存
                };

                // 添加到打開的窗口列表
                _openNoteWindows[noteId] = noteWindow;

                // 顯示窗口
                noteWindow.Show();
            }
        }

        // 鼠標進入調整大小的控制區域時
        private void Thumb_MouseEnter(object sender, MouseEventArgs e)
        {
            // 可以選擇在此顯示調整區域的邊框或提示
        }

        // 鼠標離開調整大小的控制區域時
        private void Thumb_MouseLeave(object sender, MouseEventArgs e)
        {
            // 可以選擇在此隱藏調整區域的邊框或提示
        }

        // 右側邊緣調整窗口寬度
        private void ThumbRight_DragDelta(object sender, System.Windows.Controls.Primitives.DragDeltaEventArgs e)
        {
            if (this.Width + e.HorizontalChange > 300) // 最小寬度
            {
                this.Width += e.HorizontalChange;
            }
        }

        // 底部邊緣調整窗口高度
        private void ThumbBottom_DragDelta(object sender, System.Windows.Controls.Primitives.DragDeltaEventArgs e)
        {
            if (this.Height + e.VerticalChange > 200) // 最小高度
            {
                this.Height += e.VerticalChange;
            }
        }

        // 右下角同時調整寬度和高度
        private void ThumbBottomRight_DragDelta(object sender, System.Windows.Controls.Primitives.DragDeltaEventArgs e)
        {
            if (this.Width + e.HorizontalChange > 300) // 最小寬度
            {
                this.Width += e.HorizontalChange;
            }

            if (this.Height + e.VerticalChange > 200) // 最小高度
            {
                this.Height += e.VerticalChange;
            }
        }

        // 更新便利貼列表
        private void UpdateNotesList()
        {
            // 清空面板
            NotesStackPanel.Children.Clear();

            // 為每個便利貼創建預覽控件
            foreach (var note in _notes)
            {
                var notePreview = new NotePreviewControl(note);

                // 訂閱事件
                notePreview.OpenNoteRequested += (s, noteId) => OpenNote(noteId);
                notePreview.DeleteNoteRequested += (s, noteId) => {
                    //var result = MessageBox.Show("確定要刪除這個便利貼嗎？", "刪除確認",
                    //                          MessageBoxButton.YesNo, MessageBoxImage.Question);

                    //if (result == MessageBoxResult.Yes)
                    //{
                        var noteToRemove = _notes.FirstOrDefault(n => n.Id == noteId);
                        if (noteToRemove != null)
                        {
                            // 如果該便利貼當前已打開，先關閉窗口
                            if (_openNoteWindows.ContainsKey(noteId))
                            {
                                _openNoteWindows[noteId].Close();
                                _openNoteWindows.Remove(noteId);
                            }

                            _notes.Remove(noteToRemove);
                            UpdateNotesList();
                            SaveAll(); // 自動保存
                        }
                    //}
                };

                // 添加到面板
                NotesStackPanel.Children.Add(notePreview);
            }
        }

        private void SettingsButton_Click(object sender, RoutedEventArgs e)
        {
            // 創建設定視窗實例
            SettingsWindow settingsWindow = new SettingsWindow();

            // 設置相對於主視窗的位置
            settingsWindow.Owner = this;

            // 以對話框方式顯示設定視窗
            settingsWindow.ShowDialog();
        }

        // 加載便利貼
        private void LoadNotes()
        {
            try
            {
                if (File.Exists(SaveFilePath))
                {
                    string jsonString = File.ReadAllText(SaveFilePath);
                    var serializedNotes = JsonConvert.DeserializeObject<List<NoteSerialized>>(jsonString);

                    if (serializedNotes != null)
                    {
                        foreach (var serializedNote in serializedNotes)
                        {
                            // 創建新的NoteSerialized實例
                            NoteSerialized noteModel = new NoteSerialized
                            {
                                Id = serializedNote.Id,
                                Content = serializedNote.Content,
                                CreationTime = serializedNote.CreationTime,
                                BackgroundColor = GetBrushFromName(serializedNote.BackgroundColorName),
                                BackgroundColorName = serializedNote.BackgroundColorName,
                                WindowLeft = serializedNote.WindowLeft,
                                WindowTop = serializedNote.WindowTop,
                                WindowWidth = serializedNote.WindowWidth,
                                WindowHeight = serializedNote.WindowHeight
                            };

                            // 設置字體屬性
                            try
                            {
                                if (!string.IsNullOrEmpty(serializedNote.FontFamilyName))
                                {
                                    noteModel.FontFamily = new System.Windows.Media.FontFamily(serializedNote.FontFamilyName);
                                    noteModel.FontFamilyName = serializedNote.FontFamilyName;
                                }
                                if (serializedNote.FontSize > 0)
                                {
                                    noteModel.FontSize = serializedNote.FontSize;
                                }
                            }
                            catch
                            {
                                // 如果字體加載失敗，使用默認字體
                                noteModel.FontFamily = new System.Windows.Media.FontFamily(".蘋方-繁");
                                noteModel.FontSize = 16;
                            }

                            _notes.Add(noteModel);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"載入便利貼失敗: {ex.Message}", "錯誤", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        // 獲取顏色名稱
        private string GetColorName(System.Windows.Media.Color color)
        {
            // 使用自定義顏色的16進制表示
            return $"#{color.R:X2}{color.G:X2}{color.B:X2}";
        }

        // 根據顏色名稱獲取畫刷
        private System.Windows.Media.SolidColorBrush GetBrushFromName(string colorName)
        {
            try
            {
                if (string.IsNullOrEmpty(colorName))
                {
                    // 默認顏色
                    return new System.Windows.Media.SolidColorBrush(
                        System.Windows.Media.Color.FromRgb(246, 185, 59)); // #f6b93b
                }

                // 嘗試將顏色名稱轉換為顏色
                var color = (System.Windows.Media.Color)System.Windows.Media.ColorConverter.ConvertFromString(colorName);
                return new System.Windows.Media.SolidColorBrush(color);
            }
            catch
            {
                // 如果轉換失敗，返回默認顏色
                return new System.Windows.Media.SolidColorBrush(
                    System.Windows.Media.Color.FromRgb(246, 185, 59)); // #f6b93b
            }
        }

        // 標題欄拖動
        private void TitleBar_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ChangedButton == MouseButton.Left)
                this.DragMove();
        }

        // 最小化按鈕
        private void MinimizeButton_Click(object sender, RoutedEventArgs e)
        {
            this.WindowState = WindowState.Minimized;
        }

        // 關閉按鈕
        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }

    public class NoteSerialized : NoteModel
    {
        public string BackgroundColorName { get; set; }
        public string FontFamilyName { get; set; }
        public double WindowLeft { get; set; }
        public double WindowTop { get; set; }
        public double WindowWidth { get; set; }
        public double WindowHeight { get; set; }
    }
}