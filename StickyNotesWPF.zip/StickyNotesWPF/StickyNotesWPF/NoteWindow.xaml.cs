﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Interop;

namespace StickyNotesWPF
{
    public partial class NoteWindow : Window
    {
        public NoteModel NoteData { get; private set; }
        private bool _isColorMenuOpen = false;
        private bool _isTextChangedByCode = false;

        public NoteWindow(NoteModel noteModel, Action addNoteAction = null)
        {
            // 確保 noteModel 不為空
            if (noteModel == null)
            {
                noteModel = new NoteModel
                {
                    Id = Guid.NewGuid(),
                    Content = "",
                    CreationTime = DateTime.Now,
                    BackgroundColor = new SolidColorBrush(Color.FromRgb(246, 185, 59))
                };
            }

            InitializeComponent();
            NoteData = noteModel;
            DataContext = NoteData;

            // 設置窗口標題（用於任務欄識別）
            // Title = $"便利貼 - {NoteData.FormattedCreationTime} - Kashionz";

            // 獲取便利貼的初始位置，如果是新建則隨機生成位置
            if (NoteData.Id == Guid.Empty)
            {
                // 確保初始化新ID
                NoteData.Id = Guid.NewGuid();

                // 新建便利貼時生成隨機位置
                Random random = new Random();
                this.Left = random.Next(50, 500);
                this.Top = random.Next(50, 300);
            }

            // 確保便利貼視窗與主視窗在同一顯示區域範圍內
            double screenWidth = SystemParameters.PrimaryScreenWidth;
            double screenHeight = SystemParameters.PrimaryScreenHeight;
            this.Left = Math.Min(Math.Max(this.Left, 0), screenWidth - 200);
            this.Top = Math.Min(Math.Max(this.Top, 0), screenHeight - 200);
        }

        // RichTextBox 加載完成後設置內容
        private void ContentRichTextBox_Loaded(object sender, RoutedEventArgs e)
        {
            _isTextChangedByCode = true;

            try
            {
                // 確保 RichTextBox 已正確初始化
                if (ContentRichTextBox != null && ContentRichTextBox.Document != null)
                {
                    // 確保初始內容正確
                    ContentRichTextBox.Document.Blocks.Clear();

                    // 防止空指針異常
                    string content = NoteData?.Content ?? "";
                    ContentRichTextBox.Document.Blocks.Add(new Paragraph(new Run(content)));

                    // 為確保焦點在最後，先定位到開頭再到結尾
                    ContentRichTextBox.Selection.Select(ContentRichTextBox.Document.ContentStart, ContentRichTextBox.Document.ContentStart);
                    ContentRichTextBox.Selection.Select(ContentRichTextBox.Document.ContentEnd, ContentRichTextBox.Document.ContentEnd);
                    ContentRichTextBox.Focus();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"初始化文本編輯器時發生錯誤: {ex.Message}", "錯誤", MessageBoxButton.OK, MessageBoxImage.Error);
            }

            _isTextChangedByCode = false;
        }

        private void AddNote_Click(object sender, RoutedEventArgs e)
        {

        }

        // 文本變更時同步到數據模型
        private void ContentRichTextBox_TextChanged(object sender, System.Windows.Controls.TextChangedEventArgs e)
        {
            if (_isTextChangedByCode || NoteData == null) return;

            try
            {
                // 使用安全的方式獲取文本
                if (ContentRichTextBox?.Document != null)
                {
                    TextRange textRange = new TextRange(ContentRichTextBox.Document.ContentStart, ContentRichTextBox.Document.ContentEnd);

                    // 檢查 textRange 是否有效
                    if (textRange != null && textRange.Text != null)
                    {
                        NoteData.Content = textRange.Text.TrimEnd('\r', '\n');
                    }
                }
            }
            catch (Exception ex)
            {
                // 在錯誤日誌中記錄錯誤，但不中斷用戶體驗
                Console.WriteLine($"更新便利貼內容時發生錯誤: {ex.Message}");
            }
        }

        // 標題欄拖動
        private void TitleBar_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ChangedButton == MouseButton.Left)
                this.DragMove();
        }

        // 關閉按鈕
        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        // 顏色選擇按鈕
        private void ColorButton_Click(object sender, RoutedEventArgs e)
        {
            if (_isColorMenuOpen || NoteData == null) return;
            _isColorMenuOpen = true;

            // 創建顏色選擇菜單
            ContextMenu colorMenu = new ContextMenu();
            colorMenu.Closed += (s, args) => _isColorMenuOpen = false;

            // 顏色列表
            Color[] colors = new Color[]
            {
                Color.FromRgb(255, 243, 171), // 淺黃
                Color.FromRgb(255, 221, 176), // 淺橙
                Color.FromRgb(255, 196, 191), // 淺紅
                Color.FromRgb(219, 243, 255), // 淺藍
                Color.FromRgb(217, 255, 224), // 淺綠
                Color.FromRgb(238, 216, 255), // 淺紫
                Color.FromRgb(246, 185, 59),  // 深黃
                Color.FromRgb(247, 147, 30),  // 橙色
                Color.FromRgb(241, 94, 88),   // 紅色
                Color.FromRgb(95, 179, 255),  // 藍色
                Color.FromRgb(124, 219, 143), // 綠色
                Color.FromRgb(177, 141, 235)  // 紫色
            };

            // 為每種顏色創建菜單項
            foreach (var color in colors)
            {
                var menuItem = new MenuItem();
                menuItem.Height = 24;
                menuItem.Padding = new Thickness(2);

                Border colorDisplay = new Border
                {
                    Width = 120,
                    Height = 20,
                    Background = new SolidColorBrush(color),
                    CornerRadius = new CornerRadius(4)
                };

                menuItem.Header = colorDisplay;
                menuItem.Tag = color;
                menuItem.Click += ColorMenuItem_Click;
                colorMenu.Items.Add(menuItem);
            }

            // 顯示菜單
            colorMenu.PlacementTarget = (Button)sender;
            colorMenu.Placement = System.Windows.Controls.Primitives.PlacementMode.Bottom;
            colorMenu.IsOpen = true;
        }

        // 顏色選擇事件
        private void ColorMenuItem_Click(object sender, RoutedEventArgs e)
        {
            if (sender is MenuItem menuItem && menuItem.Tag is Color color && NoteData != null)
            {
                NoteData.BackgroundColor = new SolidColorBrush(color);
            }
        }

        // 自定義調整大小邏輯
        private void ResizeThumb_DragDelta(object sender, System.Windows.Controls.Primitives.DragDeltaEventArgs e)
        {
            if (this.Width + e.HorizontalChange > 200) // 最小寬度
            {
                this.Width += e.HorizontalChange;
            }

            if (this.Height + e.VerticalChange > 150) // 最小高度
            {
                this.Height += e.VerticalChange;
            }
        }
    }
}